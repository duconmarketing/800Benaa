<?php
defined('C5_EXECUTE') or die("Access Denied.");

echo \Concrete\Package\Amp\Amp\Converter::content($controller);
