<?php

return [
    'https://www.cloudflare.com/ips-v4',
    'https://www.cloudflare.com/ips-v6'
];
