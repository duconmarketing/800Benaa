# community_store_paypal_standard
Paypal Standard payments for Community Store for concrete5

Install Community Store First.
